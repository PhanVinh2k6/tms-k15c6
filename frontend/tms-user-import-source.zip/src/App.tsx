import { ChangeEvent, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Bell,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  CloudUpload,
  Download,
  FileSpreadsheet,
  Filter,
  Home,
  LayoutDashboard,
  ListChecks,
  LogOut,
  MoreHorizontal,
  RotateCcw,
  Search,
  Settings,
  ShieldCheck,
  Upload,
  Users,
  XCircle,
} from 'lucide-react';
import './styles.css';

type Step = 'upload' | 'preview' | 'result';
type RowStatus = 'valid' | 'error';
type FilterStatus = 'all' | RowStatus;

type UserRow = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: string;
  status: RowStatus;
  error?: string;
};

const initialRows: UserRow[] = [
  { id: 1, fullName: 'Nguyễn Minh Anh', email: 'minhanh.nguyen@tms.vn', phone: '090 123 4567', role: 'Học viên', status: 'valid' },
  { id: 2, fullName: 'Trần Hoàng Nam', email: 'hoangnam.tran@tms.vn', phone: '091 234 5678', role: 'Học viên', status: 'valid' },
  { id: 3, fullName: 'Lê Thùy Dương', email: 'thuyduong.le@tms.vn', phone: '098 345 6789', role: 'Học viên', status: 'valid' },
  { id: 4, fullName: 'Phạm Quang Huy', email: 'quanghuy.pham@tms.vn', phone: '093 456 7890', role: 'Học viên', status: 'valid' },
  { id: 5, fullName: 'Vũ Ngọc Mai', email: 'ngocmai.vu@tms.vn', phone: '097 567 8901', role: 'Học viên', status: 'valid' },
  { id: 6, fullName: 'Đỗ Đức Anh', email: 'ducanh.do@tms.vn', phone: '096 678 9012', role: 'Học viên', status: 'valid' },
  { id: 7, fullName: 'Bùi Khánh Linh', email: 'khanhlinh.bui@tms.vn', phone: '094 789 0123', role: 'Học viên', status: 'valid' },
  { id: 8, fullName: 'Hoàng Gia Bảo', email: 'giabao.hoang@tms.vn', phone: '092 890 1234', role: 'Học viên', status: 'valid' },
  { id: 9, fullName: 'Nguyễn Thị Hà', email: 'nguyenthihagmail.com', phone: '091 111 2233', role: 'Học viên', status: 'error', error: 'Email không đúng định dạng' },
  { id: 10, fullName: 'Mai Quốc Việt', email: 'quocviet.mai@tms.vn', phone: '098 000 0000', role: '', status: 'error', error: 'Chưa chọn vai trò người dùng' },
];

const steps = [
  { key: 'upload' as Step, label: 'Tải tệp Excel', helper: 'Chọn tệp dữ liệu' },
  { key: 'preview' as Step, label: 'Xem trước và kiểm tra', helper: 'Kiểm tra dữ liệu' },
  { key: 'result' as Step, label: 'Kết quả nhập người dùng', helper: 'Hoàn tất nhập' },
];

const navItems = [
  { label: 'Tổng quan', icon: LayoutDashboard },
  { label: 'Quản lý người dùng', icon: Users, active: true },
  { label: 'Quản lý khóa học', icon: ListChecks },
  { label: 'Lịch đào tạo', icon: BarChart3 },
];

function App() {
  const [step, setStep] = useState<Step>('upload');
  const [rows, setRows] = useState<UserRow[]>(initialRows);
  const [fileName, setFileName] = useState('danh-sach-hoc-vien-khoa-07.xlsx');
  const [hasFile, setHasFile] = useState(false);
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [query, setQuery] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validCount = rows.filter((row) => row.status === 'valid').length;
  const errorCount = rows.filter((row) => row.status === 'error').length;

  const visibleRows = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesFilter = filter === 'all' || row.status === filter;
      const matchesQuery = !normalized || [row.fullName, row.email, row.phone, row.role].some((value) => value.toLowerCase().includes(normalized));
      return matchesFilter && matchesQuery;
    });
  }, [filter, query, rows]);

  const handleFile = (file?: File) => {
    if (!file) return;
    setFileName(file.name);
    setHasFile(true);
    setRows(initialRows);
    setStep('preview');
    setFilter('all');
    setQuery('');
  };

  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    handleFile(event.target.files?.[0]);
    event.target.value = '';
  };

  const downloadTemplate = () => {
    const content = '\ufeffHọ và tên\tEmail\tSố điện thoại\tVai trò\nNguyễn Văn A\tnguyenvana@example.com\t090 123 4567\tHọc viên\n';
    const blob = new Blob([content], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'mau-nhap-nguoi-dung.xls';
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    setStep('upload');
    setHasFile(false);
    setRows(initialRows);
    setFileName('danh-sach-hoc-vien-khoa-07.xlsx');
    setFilter('all');
    setQuery('');
  };

  const selectFile = () => fileInputRef.current?.click();
  const stepIndex = steps.findIndex((item) => item.key === step);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark" aria-hidden="true">
            <span /><span /><span /><span />
          </div>
          <div>
            <div className="brand-name">TMS</div>
            <div className="brand-caption">Training Management System</div>
          </div>
        </div>

        <div className="workspace-switcher">
          <div className="workspace-avatar">T</div>
          <div className="workspace-copy">
            <span>Hệ thống đào tạo</span>
            <strong>Vận hành nội bộ</strong>
          </div>
          <ChevronDown size={15} />
        </div>

        <nav className="main-nav" aria-label="Điều hướng chính">
          <div className="nav-label">KHÔNG GIAN LÀM VIỆC</div>
          {navItems.map(({ label, icon: Icon, active }) => (
            <button className={`nav-item ${active ? 'active' : ''}`} key={label} type="button">
              <Icon size={17} strokeWidth={active ? 2.3 : 1.9} />
              <span>{label}</span>
              {label === 'Quản lý người dùng' && <span className="nav-count">128</span>}
            </button>
          ))}
          <div className="nav-label nav-label-spaced">HỆ THỐNG</div>
          <button className="nav-item" type="button"><ShieldCheck size={17} /><span>Phân quyền</span></button>
          <button className="nav-item" type="button"><Settings size={17} /><span>Cài đặt</span></button>
        </nav>

        <div className="sidebar-bottom">
          <div className="support-card">
            <div className="support-icon"><CircleHelp size={17} /></div>
            <div><strong>Cần trợ giúp?</strong><span>Liên hệ đội vận hành</span></div>
            <ArrowRight size={15} />
          </div>
          <div className="profile-row">
            <div className="profile-avatar">MA</div>
            <div className="profile-copy"><strong>Minh Anh</strong><span>Quản trị hệ thống</span></div>
            <MoreHorizontal size={17} />
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb"><Home size={14} /><span>/</span><span>Quản lý người dùng</span><span>/</span><strong>Nhập danh sách hàng loạt</strong></div>
          <div className="top-actions"><button className="icon-button" type="button" aria-label="Thông báo"><Bell size={18} /><span className="notification-dot" /></button><div className="top-divider" /><span className="top-date">Thứ Tư, 08 tháng 10, 2026</span></div>
        </header>

        <div className="content-wrap">
          <div className="page-heading">
            <div><div className="eyebrow">QUẢN LÝ NGƯỜI DÙNG <span>•</span> S2-01</div><h1>Nhập danh sách người dùng hàng loạt từ Excel</h1><p>Tạo nhanh tài khoản cho học viên bằng cách tải lên danh sách từ tệp Excel.</p></div>
            <div className="heading-status"><span className="status-dot" /> Chưa bắt đầu</div>
          </div>

          <div className="stepper" aria-label="Tiến trình nhập người dùng">
            {steps.map((item, index) => {
              const completed = index < stepIndex;
              const current = index === stepIndex;
              return <div className="stepper-item" key={item.key}><div className={`step-circle ${completed ? 'completed' : ''} ${current ? 'current' : ''}`}>{completed ? <Check size={15} strokeWidth={3} /> : index + 1}</div><div className="step-copy"><strong>{item.label}</strong><span>{item.helper}</span></div>{index < steps.length - 1 && <div className={`step-line ${completed ? 'completed' : ''}`} />}</div>;
            })}
          </div>

          {step === 'upload' && <UploadStep hasFile={hasFile} fileName={fileName} isDragging={isDragging} selectFile={selectFile} downloadTemplate={downloadTemplate} handleFile={handleFile} setIsDragging={setIsDragging} fileInputRef={fileInputRef} onFileChange={onFileChange} />}
          {step === 'preview' && <PreviewStep rows={rows} visibleRows={visibleRows} validCount={validCount} errorCount={errorCount} fileName={fileName} filter={filter} query={query} setFilter={setFilter} setQuery={setQuery} onBack={() => setStep('upload')} onImport={() => setStep('result')} />}
          {step === 'result' && <ResultStep total={rows.length} validCount={validCount} errorCount={errorCount} fileName={fileName} onBack={() => setStep('preview')} reset={reset} />}
        </div>
      </main>
    </div>
  );
}

type UploadStepProps = {
  hasFile: boolean;
  fileName: string;
  isDragging: boolean;
  selectFile: () => void;
  downloadTemplate: () => void;
  handleFile: (file?: File) => void;
  setIsDragging: (value: boolean) => void;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  onFileChange: (event: ChangeEvent<HTMLInputElement>) => void;
};

function UploadStep({ hasFile, fileName, isDragging, selectFile, downloadTemplate, handleFile, setIsDragging, fileInputRef, onFileChange }: UploadStepProps) {
  return <section className="panel upload-panel">
    <div className="panel-header"><div><h2>Bắt đầu nhập danh sách</h2><p>Tải lên tệp Excel chứa thông tin người dùng để bắt đầu.</p></div><div className="panel-help"><CircleHelp size={16} /> <span>Hướng dẫn nhập dữ liệu</span></div></div>
    <div className="template-strip"><div className="template-icon"><FileSpreadsheet size={20} /></div><div className="template-copy"><strong>Chưa có tệp mẫu?</strong><span>Tải tệp mẫu để điền đúng định dạng trước khi tải lên.</span></div><button className="secondary-button" type="button" onClick={downloadTemplate}><Download size={16} /> Tải tệp mẫu</button></div>
    <div className={`drop-zone ${isDragging ? 'dragging' : ''} ${hasFile ? 'has-file' : ''}`} onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }} onDragLeave={() => setIsDragging(false)} onDrop={(event) => { event.preventDefault(); setIsDragging(false); handleFile(event.dataTransfer.files?.[0]); }}>
      <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={onFileChange} />
      <div className="upload-orb"><CloudUpload size={31} strokeWidth={1.7} /></div>
      {hasFile ? <><h3>{fileName}</h3><p>Tệp đã sẵn sàng để xem trước và kiểm tra.</p><button className="text-button" type="button" onClick={selectFile}>Chọn tệp khác</button></> : <><h3>Kéo thả tệp Excel vào đây</h3><p>hoặc <button className="inline-button" type="button" onClick={selectFile}>chọn tệp từ máy tính</button></p><span className="file-note">Định dạng hỗ trợ: .xlsx, .xls · Kích thước tối đa 10MB</span></>}
    </div>
    <div className="format-note"><AlertCircle size={15} /><span>Đảm bảo tệp có đủ 4 cột bắt buộc: <strong>Họ và tên, Email, Số điện thoại, Vai trò</strong>.</span></div>
    <div className="panel-footer"><span className="required-note"><span>*</span> Tất cả các trường trong tệp mẫu đều cần được điền.</span><button className="primary-button" type="button" disabled={!hasFile} onClick={() => {}}><span>Tiếp tục kiểm tra</span><ArrowRight size={16} /></button></div>
  </section>;
}

type PreviewStepProps = {
  rows: UserRow[];
  visibleRows: UserRow[];
  validCount: number;
  errorCount: number;
  fileName: string;
  filter: FilterStatus;
  query: string;
  setFilter: (filter: FilterStatus) => void;
  setQuery: (query: string) => void;
  onBack: () => void;
  onImport: () => void;
};

function PreviewStep({ rows, visibleRows, validCount, errorCount, fileName, filter, query, setFilter, setQuery, onBack, onImport }: PreviewStepProps) {
  return <section className="panel preview-panel">
    <div className="panel-header preview-header"><div><div className="file-breadcrumb"><FileSpreadsheet size={17} /><strong>{fileName}</strong><span className="file-size">128 KB</span><span className="ready-badge"><CheckCircle2 size={13} /> Đã tải lên</span></div><h2>Kiểm tra dữ liệu trước khi nhập</h2><p>Vui lòng rà soát các dòng có lỗi. Chỉ các dòng hợp lệ mới được tạo tài khoản.</p></div><button className="ghost-button" type="button" onClick={onBack}><RotateCcw size={15} /> Chọn tệp khác</button></div>
    <div className="stats-grid"><StatCard label="Tổng số dòng" value={rows.length} tone="neutral" icon={<ListChecks size={18} />} /><StatCard label="Dòng hợp lệ" value={validCount} tone="success" icon={<BadgeCheck size={18} />} /><StatCard label="Dòng có lỗi" value={errorCount} tone="error" icon={<AlertCircle size={18} />} /></div>
    <div className="table-toolbar"><div className="filter-tabs"><button className={filter === 'all' ? 'selected' : ''} type="button" onClick={() => setFilter('all')}>Tất cả <span>{rows.length}</span></button><button className={filter === 'valid' ? 'selected success-tab' : ''} type="button" onClick={() => setFilter('valid')}>Hợp lệ <span>{validCount}</span></button><button className={filter === 'error' ? 'selected error-tab' : ''} type="button" onClick={() => setFilter('error')}>Có lỗi <span>{errorCount}</span></button></div><div className="toolbar-actions"><div className="search-field"><Search size={16} /><input aria-label="Tìm kiếm người dùng" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Tìm theo tên hoặc email" /></div><button className="filter-button" type="button"><Filter size={15} /> Bộ lọc</button></div></div>
    <div className="table-wrap"><table><thead><tr><th className="index-col">#</th><th>HỌ VÀ TÊN</th><th>EMAIL</th><th>SỐ ĐIỆN THOẠI</th><th>VAI TRÒ</th><th>TRẠNG THÁI</th><th>LỖI</th></tr></thead><tbody>{visibleRows.map((row) => <tr key={row.id} className={row.status === 'error' ? 'error-row' : ''}><td className="row-index">{String(row.id).padStart(2, '0')}</td><td><div className="person-cell"><div className={`mini-avatar avatar-${(row.id % 5) + 1}`}>{row.fullName.split(' ').map((part) => part[0]).slice(-2).join('')}</div><strong>{row.fullName}</strong></div></td><td className={row.status === 'error' ? 'bad-cell' : ''}>{row.email}</td><td>{row.phone}</td><td>{row.role || <span className="empty-value">—</span>}</td><td><span className={`row-status ${row.status}`}><span />{row.status === 'valid' ? 'Hợp lệ' : 'Có lỗi'}</span></td><td>{row.error ? <span className="error-message"><AlertCircle size={13} /> {row.error}</span> : <span className="empty-value">—</span>}</td></tr>)}</tbody></table>{visibleRows.length === 0 && <div className="empty-state"><Search size={22} /><strong>Không tìm thấy dòng phù hợp</strong><span>Thử thay đổi từ khóa hoặc bộ lọc.</span></div>}</div>
    <div className="preview-footnote"><div><AlertCircle size={15} /><span>Các dòng có lỗi sẽ được <strong>bỏ qua tự động</strong> khi nhập.</span></div><span>Đang hiển thị {visibleRows.length}/{rows.length} dòng</span></div>
    <div className="panel-footer"><button className="back-button" type="button" onClick={onBack}><ArrowLeft size={16} /> Quay lại</button><div className="footer-actions"><span className="import-note"><CheckCircle2 size={15} /> Sẵn sàng nhập {validCount} tài khoản</span><button className="primary-button" type="button" onClick={onImport}><Upload size={16} /> Nhập {validCount} tài khoản hợp lệ</button></div></div>
  </section>;
}

function StatCard({ label, value, tone, icon }: { label: string; value: number; tone: 'neutral' | 'success' | 'error'; icon: React.ReactNode }) {
  return <div className={`stat-card ${tone}`}><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong></div></div>;
}

function ResultStep({ total, validCount, errorCount, fileName, onBack, reset }: { total: number; validCount: number; errorCount: number; fileName: string; onBack: () => void; reset: () => void }) {
  return <section className="panel result-panel"><div className="result-hero"><div className="result-check"><Check size={31} strokeWidth={2.8} /></div><div className="result-kicker">NHẬP DỮ LIỆU HOÀN TẤT</div><h2>Đã hoàn tất nhập danh sách</h2><p>Các tài khoản hợp lệ đã được tạo thành công trong hệ thống.</p></div><div className="result-summary"><div><span>Tổng số dòng</span><strong>{total}</strong></div><div className="result-divider" /><div className="result-success"><span>Tài khoản nhập thành công</span><strong>{validCount}</strong><small><CheckCircle2 size={13} /> Đã tạo tài khoản</small></div><div className="result-divider" /><div className="result-error"><span>Dòng bị bỏ qua</span><strong>{errorCount}</strong><small><XCircle size={13} /> Cần chỉnh sửa</small></div></div><div className="result-details"><div className="details-heading"><div><h3>Chi tiết lượt nhập</h3><p>{fileName} · Vừa hoàn tất</p></div><span className="success-badge"><CheckCircle2 size={14} /> Thành công</span></div><div className="result-list"><div><span className="result-list-icon success"><Check size={15} /></span><span><strong>{validCount} dòng hợp lệ</strong><small>Tài khoản đã sẵn sàng sử dụng</small></span><em>Đã nhập</em></div><div><span className="result-list-icon error"><XCircle size={15} /></span><span><strong>{errorCount} dòng có lỗi</strong><small>Dòng lỗi được bỏ qua, không tạo tài khoản</small></span><em className="error-text">Đã bỏ qua</em></div></div></div><div className="panel-footer result-footer"><button className="back-button" type="button" onClick={onBack}><ArrowLeft size={16} /> Xem lại dữ liệu</button><button className="primary-button" type="button" onClick={reset}><RotateCcw size={16} /> Bắt đầu lượt nhập mới</button></div></section>;
}

export default App;
