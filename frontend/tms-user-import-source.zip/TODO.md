# TODO — S2-01 Nhập danh sách người dùng hàng loạt từ Excel

- [ ] **S2-01 — Tải được tệp mẫu**
  - Tải được tệp mẫu.
  - Hiển thị giao diện tải tệp Excel và hướng dẫn định dạng.

- [ ] **S2-01 — Xem trước và báo lỗi theo từng dòng trước khi nhập**
  - Xem trước và báo lỗi theo từng dòng trước khi nhập.
  - Hiển thị số dòng tổng, dòng hợp lệ và dòng lỗi.
  - Cho phép xem/lọc các dòng có lỗi với nội dung lỗi dễ hiểu.

- [ ] **S2-01 — Bỏ qua dòng lỗi, nhập dòng hợp lệ và báo cáo tổng kết**
  - Dòng lỗi bị bỏ qua, dòng hợp lệ vẫn được nhập, có báo cáo tổng kết.
  - Báo cáo tổng kết gồm tổng số dòng, số tài khoản nhập thành công, số dòng bị bỏ qua và chi tiết kết quả.
  - Có thao tác quay lại sửa/chọn tệp khác và bắt đầu một lượt nhập mới sau khi hoàn tất.
