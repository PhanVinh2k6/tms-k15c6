# Kế hoạch triển khai — S2-01 Nhập danh sách người dùng hàng loạt từ Excel

## Phạm vi

Prototype frontend React + TypeScript, không có backend và không có cơ sở dữ liệu. Toàn bộ dữ liệu dùng thử được lưu trong state của phiên trình duyệt. Giao diện tiếng Việt, giữ nguyên tinh thần của ảnh tham chiếu: màn hình quản trị TMS nền sáng, nhấn tím, thẻ bo góc nhẹ, bảng dữ liệu rõ ràng và tiến trình 3 bước.

## Luồng sản phẩm

1. **Tải tệp Excel**: hiển thị tiêu đề, mô tả, nút tải tệp mẫu, vùng kéo-thả/chọn tệp và thông tin định dạng hỗ trợ.
2. **Xem trước và kiểm tra**: trình bày số dòng tổng, hợp lệ, lỗi; bảng xem trước có trạng thái từng dòng, thông báo lỗi cụ thể, lọc Tất cả/Hợp lệ/Có lỗi. Khi có file thật, đọc tên file và dùng dữ liệu mock an toàn để minh hoạ; khi chưa có file, nút chuyển bước bị khoá.
3. **Kết quả nhập**: mô phỏng nhập các dòng hợp lệ và bỏ qua dòng lỗi; hiển thị báo cáo tổng kết, chi tiết thành công/bỏ qua và cho phép quay lại chọn tệp khác hoặc bắt đầu lượt nhập mới.

## Thiết kế

- **Design movement**: Enterprise SaaS tối giản, lấy dashboard vận hành hiện đại làm nền, bám sát ảnh tham chiếu.
- **Core principles**: rõ thứ bậc thông tin; trạng thái có thể quét nhanh; hành động chính nổi bật; khoảng thở và đường viền nhẹ để giảm tải nhận thức.
- **Color philosophy**: nền xám-lavender rất nhạt để tạo không gian làm việc; tím thương hiệu `#6557E8` cho tiến trình, CTA và điểm nhấn; xanh lá cho thành công; đỏ/hồng cho lỗi; vàng cho cảnh báo. Không dùng ảnh trang trí vì đây là công cụ nội bộ.
- **Layout paradigm**: shell quản trị với sidebar cố định bên trái và khu vực nội dung theo trục dọc; tiêu đề và tiến trình ở trên, card nội dung ở giữa, footer hành động cố định trong card.
- **Signature elements**: logo TMS dạng ô lưới nhỏ; stepper 3 bước với chấm tím; card nền trắng với shadow mỏng; badge trạng thái dạng pill.
- **Interaction philosophy**: hành động rõ ràng và có phản hồi ngay; mọi lỗi gắn trực tiếp với dòng; hover/focus tinh tế; chuyển bước bằng state, không reload.
- **Animation**: fade/slide nhẹ khi đổi bước, progress bar chuyển mượt, nút có active/hover nhưng không gây phân tán.
- **Typography**: Inter, fallback system sans-serif; tiêu đề 28/34 đậm vừa, section 16/24, body 14/20, caption 12/18.
- **Brand essence**: TMS giúp đội vận hành nhập học viên nhanh, đúng và có thể kiểm soát — điềm tĩnh, chính xác, hỗ trợ.
- **Brand voice**: CTA trực tiếp như “Tải tệp mẫu”, “Kiểm tra dữ liệu”, “Nhập 8 tài khoản hợp lệ”; microcopy hướng dẫn và giải thích, tránh thuật ngữ kỹ thuật.
- **Wordmark & logo**: biểu tượng 2x2 ô vuông bo góc với chữ TMS bên cạnh, thể hiện dữ liệu được tổ chức.
- **Signature brand color**: tím `#6557E8`.

## Cấu trúc dự án

- `index.html`: entry HTML và font import.
- `src/main.tsx`: mount React.
- `src/App.tsx`: state machine 3 bước, mock rows, tải mẫu, chọn file, lọc bảng, chuyển bước và reset.
- `src/styles.css`: token màu, shell/sidebar, stepper, card, table, responsive.
- `public/manus-routes.json`: manifest route `/` cho Preview/Published.
- `app.config.ts`: metadata logo literal.

## Ràng buộc kỹ thuật

- React + TypeScript + Vite, không cài backend/database.
- Không thay đổi nội dung nghiệp vụ và màu sắc chủ đạo của ảnh tham chiếu; chỉ bổ sung hành vi tương tác cần thiết để đáp ứng acceptance criteria.
- Dữ liệu demo có 10 dòng gồm 8 hợp lệ và 2 dòng lỗi để người xem kiểm chứng việc bỏ qua lỗi và nhập phần hợp lệ.
