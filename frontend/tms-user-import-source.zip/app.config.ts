export default {
  logoUrl: "https://placehold.co/64x64/6557E8/FFFFFF.png?text=TMS",
};
