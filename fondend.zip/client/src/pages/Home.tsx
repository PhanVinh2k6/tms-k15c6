import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  CircleHelp,
  CircleCheck,
  Building2,
  Eye,
  EyeOff,
  Fingerprint,
  KeyRound,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
  UserPlus,
} from "lucide-react";

const DEMO_ACCOUNTS = [
  { email: "admin@tms.vn", password: "123456", role: "Training Manager", initials: "TM" },
  { email: "giangvien@tms.vn", password: "123456", role: "Instructor", initials: "GV" },
  { email: "hocvien@tms.vn", password: "123456", role: "Student", initials: "HV" },
];

const LOCK_DURATION_MS = 15 * 60 * 1000;

function formatCountdown(milliseconds: number) {
  const totalSeconds = Math.max(0, Math.ceil(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const seconds = (totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

export default function Home() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [status, setStatus] = useState<"idle" | "error" | "success" | "recovery" | "register-error" | "register-success">("idle");
  const [activeRole, setActiveRole] = useState(DEMO_ACCOUNTS[0]);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [fullName, setFullName] = useState("");
  const [registerRole, setRegisterRole] = useState("Student");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);

  const isLocked = lockedUntil !== null && lockedUntil > now;
  const remainingTime = lockedUntil ? lockedUntil - now : 0;

  useEffect(() => {
    if (!lockedUntil) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [lockedUntil]);

  useEffect(() => {
    if (lockedUntil && lockedUntil <= now) {
      setLockedUntil(null);
      setFailedAttempts(0);
      setStatus("idle");
    }
  }, [lockedUntil, now]);

  const attemptLabel = useMemo(() => {
    if (failedAttempts === 0) return "Bảo vệ tài khoản của bạn";
    return `Lần thử không thành công ${failedAttempts}/5`;
  }, [failedAttempts]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (isLocked) return;

    const account = DEMO_ACCOUNTS.find(
      (item) => item.email === email.trim().toLowerCase() && item.password === password,
    );

    if (!account) {
      const nextAttempts = failedAttempts + 1;
      setFailedAttempts(nextAttempts);
      setStatus("error");
      if (nextAttempts >= 5) {
        setLockedUntil(Date.now() + LOCK_DURATION_MS);
      }
      return;
    }

    setActiveRole(account);
    setFailedAttempts(0);
    setStatus("success");
  }

  function handleRecovery() {
    setStatus("recovery");
  }

  function handleRegister(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (password !== confirmPassword) {
      setStatus("register-error");
      return;
    }
    if (!agreeTerms) {
      setStatus("register-error");
      return;
    }
    setStatus("register-success");
  }

  function switchAuthMode(mode: "login" | "register") {
    setAuthMode(mode);
    setStatus("idle");
    setPassword("");
    setConfirmPassword("");
  }

  function resetLogin() {
    setStatus("idle");
    setPassword("");
    setAuthMode("login");
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#f7f5f0] text-[#15212b]">
      <div className="grid min-h-screen lg:grid-cols-[minmax(420px,0.92fr)_minmax(520px,1.08fr)]">
        <section className="relative isolate flex min-h-[560px] flex-col overflow-hidden bg-[#122333] px-7 py-7 text-[#f5f1e8] sm:px-12 sm:py-10 lg:min-h-screen lg:px-16 lg:py-12 xl:px-24">
          <div className="grid-glow pointer-events-none absolute inset-0 opacity-70" />
          <div className="absolute -right-24 top-20 h-72 w-72 rounded-full bg-[#e46850]/20 blur-3xl" />
          <div className="absolute -bottom-32 -left-24 h-80 w-80 rounded-full bg-[#57b8aa]/15 blur-3xl" />

          <header className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="logo-mark flex h-11 w-11 items-center justify-center rounded-[14px] bg-[#e46850] text-[#122333] shadow-[0_12px_28px_rgba(228,104,80,0.22)]">
                <span className="font-display text-xl font-bold tracking-[-0.08em]">tm</span>
              </div>
              <div>
                <p className="font-display text-base font-semibold tracking-[-0.02em]">TMS</p>
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9eb0bb]">Training management</p>
              </div>
            </div>
            <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#9eb0bb] sm:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-[#57b8aa] shadow-[0_0_0_4px_rgba(87,184,170,0.12)]" />
              System online
            </div>
          </header>

          <div className="relative z-10 my-auto max-w-[540px] py-16 lg:py-24">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#e46850]/30 bg-[#e46850]/10 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-[#f3a28f]">
              <Sparkles className="h-3.5 w-3.5" />
              Sprint 01 · S1-01
            </div>
            <h1 className="max-w-[560px] font-display text-[clamp(2.7rem,5.5vw,5.6rem)] font-semibold leading-[0.98] tracking-[-0.075em] text-[#f7f3e9]">
              Một nơi cho toàn bộ hành trình đào tạo.
            </h1>
            <p className="mt-7 max-w-[430px] text-[15px] leading-7 text-[#a9bac4] sm:text-base">
              Từ ghi danh đến tốt nghiệp — TMS giúp đội ngũ vận hành nhìn thấy đúng dữ liệu, đúng thời điểm và đưa ra quyết định nhanh hơn.
            </p>

            <div className="mt-12 grid max-w-[430px] grid-cols-2 gap-3 sm:grid-cols-3">
              {[
                ["01", "Ghi danh"],
                ["02", "Xếp lịch"],
                ["03", "Bảng điểm"],
              ].map(([number, label]) => (
                <div key={number} className="border-l border-white/15 pl-3">
                  <p className="font-display text-lg font-semibold text-[#f7f3e9]">{number}</p>
                  <p className="mt-1 text-[11px] uppercase tracking-[0.14em] text-[#8297a3]">{label}</p>
                </div>
              ))}
            </div>
          </div>

          <footer className="relative z-10 flex items-end justify-between gap-6 text-[11px] leading-5 text-[#78909d]">
            <p className="max-w-[220px]">Dữ liệu lớp học chỉ dành cho người dùng được cấp quyền.</p>
            <div className="hidden text-right sm:block">
              <p className="font-display text-sm font-medium text-[#b7c5ca]">K15C6 / pilot</p>
              <p>Built for better learning ops</p>
            </div>
          </footer>
        </section>

        <section className="relative flex min-h-[640px] items-center justify-center px-5 py-12 sm:px-10 lg:px-16 xl:px-24">
          <div className="absolute right-8 top-8 hidden items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8a9699] sm:flex">
            <ShieldCheck className="h-4 w-4 text-[#57a79b]" />
            Protected workspace
          </div>

          <div className="w-full max-w-[500px] animate-rise">
            {status === "success" ? (
              <SuccessState account={activeRole} onReset={resetLogin} />
            ) : status === "register-success" ? (
              <RegisterSuccessState fullName={fullName} onLogin={() => switchAuthMode("login")} />
            ) : (
              <>
                <div className="mb-7">
                  <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#e5f1ed] text-[#2f8177]">
                    {authMode === "login" ? <Fingerprint className="h-6 w-6" strokeWidth={1.8} /> : <UserPlus className="h-6 w-6" strokeWidth={1.8} />}
                  </div>
                  <div className="mb-5 flex w-fit rounded-xl bg-[#edf0ed] p-1">
                    <button type="button" onClick={() => switchAuthMode("login")} className={`rounded-lg px-4 py-2 text-xs font-bold transition-all ${authMode === "login" ? "bg-white text-[#243740] shadow-sm" : "text-[#899497] hover:text-[#526268]"}`}>Đăng nhập</button>
                    <button type="button" onClick={() => switchAuthMode("register")} className={`rounded-lg px-4 py-2 text-xs font-bold transition-all ${authMode === "register" ? "bg-white text-[#243740] shadow-sm" : "text-[#899497] hover:text-[#526268]"}`}>Đăng ký</button>
                  </div>
                  <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-[#d9654e]">{authMode === "login" ? "Chào mừng trở lại" : "Bắt đầu cùng TMS"}</p>
                  <h2 className="font-display text-[clamp(2.25rem,4vw,3.6rem)] font-semibold leading-[0.98] tracking-[-0.065em] text-[#162632]">{authMode === "login" ? "Đăng nhập vào TMS" : "Tạo tài khoản TMS"}</h2>
                  <p className="mt-4 max-w-[390px] text-sm leading-6 text-[#778389]">{authMode === "login" ? "Sử dụng tài khoản đã được cấp để truy cập phần việc của bạn." : "Đăng ký để tham gia workspace đào tạo và theo dõi hành trình học tập của bạn."}</p>
                </div>

                {status === "recovery" && authMode === "login" && (
                  <div className="mb-5 flex gap-3 rounded-2xl border border-[#b9ddd5] bg-[#edf8f5] p-4 text-sm leading-5 text-[#36766d]" role="status">
                    <Mail className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>Đã ghi nhận yêu cầu. Vui lòng kiểm tra email công việc để khôi phục mật khẩu.</span>
                  </div>
                )}

                {status === "error" && authMode === "login" && !isLocked && (
                  <div className="mb-5 flex gap-3 rounded-2xl border border-[#efc3bb] bg-[#fff2ef] p-4 text-sm leading-5 text-[#a84b3a]" role="alert">
                    <CircleHelp className="mt-0.5 h-4 w-4 shrink-0" />
                    <div><p className="font-semibold">Email hoặc mật khẩu không đúng</p><p className="mt-1 text-xs text-[#b7685a]">Vui lòng kiểm tra lại thông tin và thử lại.</p></div>
                  </div>
                )}

                {isLocked && authMode === "login" && (
                  <div className="mb-5 flex gap-3 rounded-2xl border border-[#e8d4a3] bg-[#fff8e8] p-4 text-sm leading-5 text-[#856528]" role="alert">
                    <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0" />
                    <div><p className="font-semibold">Tài khoản tạm thời bị khóa</p><p className="mt-1 text-xs leading-5 text-[#9a7b3e]">Bạn đã nhập sai 5 lần liên tiếp. Có thể thử lại sau <strong>{formatCountdown(remainingTime)}</strong>.</p></div>
                  </div>
                )}

                {status === "register-error" && authMode === "register" && (
                  <div className="mb-5 flex gap-3 rounded-2xl border border-[#efc3bb] bg-[#fff2ef] p-4 text-sm leading-5 text-[#a84b3a]" role="alert">
                    <CircleHelp className="mt-0.5 h-4 w-4 shrink-0" />
                    <div><p className="font-semibold">Chưa thể tạo tài khoản</p><p className="mt-1 text-xs text-[#b7685a]">Kiểm tra mật khẩu xác nhận và đồng ý với điều khoản sử dụng.</p></div>
                  </div>
                )}

                {authMode === "login" ? (
                  <form className="space-y-5" onSubmit={handleSubmit}>
                    <div>
                      <label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="email"><Mail className="h-3.5 w-3.5 text-[#a4afb2]" />Email công việc</label>
                      <input id="email" name="email" type="email" autoComplete="email" placeholder="ten@doanhnghiep.vn" value={email} onChange={(event) => { setEmail(event.target.value); if (status !== "idle") setStatus("idle"); }} disabled={isLocked} className="field-input" required />
                    </div>
                    <div>
                      <div className="mb-2.5 flex items-center justify-between"><label className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="password"><KeyRound className="h-3.5 w-3.5 text-[#a4afb2]" />Mật khẩu</label><button type="button" onClick={handleRecovery} className="text-xs font-semibold text-[#bb5745] transition-colors hover:text-[#8e382c]">Quên mật khẩu?</button></div>
                      <div className="relative"><input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Nhập mật khẩu của bạn" value={password} onChange={(event) => { setPassword(event.target.value); if (status !== "idle") setStatus("idle"); }} disabled={isLocked} className="field-input pr-12" required /><button type="button" onClick={() => setShowPassword((visible) => !visible)} disabled={isLocked} aria-label={showPassword ? "Ẩn mật khẩu" : "Hiện mật khẩu"} className="absolute right-0 top-0 flex h-full w-12 items-center justify-center text-[#96a2a5] transition-colors hover:text-[#33444b] disabled:cursor-not-allowed disabled:opacity-50">{showPassword ? <EyeOff className="h-[18px] w-[18px]" /> : <Eye className="h-[18px] w-[18px]" />}</button></div>
                    </div>
                    <div className="flex items-center justify-between gap-4 pt-1"><label className="flex cursor-pointer items-center gap-2.5 text-sm text-[#647177]"><input type="checkbox" checked={rememberMe} onChange={(event) => setRememberMe(event.target.checked)} className="custom-checkbox" />Ghi nhớ đăng nhập</label><span className="text-[11px] font-medium text-[#a1abad]">{attemptLabel}</span></div>
                    <button type="submit" disabled={isLocked} className="primary-button group flex w-full items-center justify-center gap-3">{isLocked ? "Đang tạm khóa" : "Đăng nhập"}{!isLocked && <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 group-hover:translate-x-1" />}</button>
                  </form>
                ) : (
                  <form className="space-y-4" onSubmit={handleRegister}>
                    <div><label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="fullName"><UserRound className="h-3.5 w-3.5 text-[#a4afb2]" />Họ và tên</label><input id="fullName" name="fullName" type="text" autoComplete="name" placeholder="Nguyễn Văn A" value={fullName} onChange={(event) => setFullName(event.target.value)} className="field-input" required /></div>
                    <div><label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="registerEmail"><Mail className="h-3.5 w-3.5 text-[#a4afb2]" />Email công việc</label><input id="registerEmail" name="registerEmail" type="email" autoComplete="email" placeholder="ten@doanhnghiep.vn" value={email} onChange={(event) => setEmail(event.target.value)} className="field-input" required /></div>
                    <div><label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="role"><Building2 className="h-3.5 w-3.5 text-[#a4afb2]" />Vai trò</label><select id="role" value={registerRole} onChange={(event) => setRegisterRole(event.target.value)} className="field-input appearance-none"><option>Student</option><option>Instructor</option><option>TA</option><option>Admissions</option></select></div>
                    <div className="grid gap-4 sm:grid-cols-2"><div><label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="registerPassword"><KeyRound className="h-3.5 w-3.5 text-[#a4afb2]" />Mật khẩu</label><input id="registerPassword" type={showPassword ? "text" : "password"} placeholder="Tối thiểu 6 ký tự" value={password} onChange={(event) => setPassword(event.target.value)} className="field-input" minLength={6} required /></div><div><label className="mb-2.5 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.14em] text-[#44545b]" htmlFor="confirmPassword"><KeyRound className="h-3.5 w-3.5 text-[#a4afb2]" />Xác nhận</label><input id="confirmPassword" type={showPassword ? "text" : "password"} placeholder="Nhập lại mật khẩu" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} className="field-input" minLength={6} required /></div></div>
                    <label className="flex cursor-pointer items-start gap-2.5 pt-1 text-xs leading-5 text-[#647177]"><input type="checkbox" checked={agreeTerms} onChange={(event) => setAgreeTerms(event.target.checked)} className="custom-checkbox mt-1" required /><span>Tôi đồng ý với <a href="#terms" className="font-semibold text-[#bb5745] hover:underline">Điều khoản sử dụng</a> và Chính sách bảo mật của TMS.</span></label>
                    <button type="submit" className="primary-button group flex w-full items-center justify-center gap-3">Tạo tài khoản <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 group-hover:translate-x-1" /></button>
                  </form>
                )}

                <div className="my-8 flex items-center gap-4"><div className="h-px flex-1 bg-[#e3e5e2]" /><span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#adb6b8]">{authMode === "login" ? "Secure access" : "Join the workspace"}</span><div className="h-px flex-1 bg-[#e3e5e2]" /></div>
                <div className="flex items-start gap-3 rounded-2xl border border-[#e5e8e5] bg-white/55 p-4"><div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#f1f4f1] text-[#6d8884]"><ShieldCheck className="h-4 w-4" /></div><div><p className="text-xs font-semibold text-[#425258]">{authMode === "login" ? "Không chia sẻ thông tin đăng nhập" : "Tài khoản được xét duyệt an toàn"}</p><p className="mt-1 text-xs leading-5 text-[#8b9698]">{authMode === "login" ? "TMS bảo vệ dữ liệu lớp học bằng phiên truy cập riêng cho từng vai trò." : "Thông tin đăng ký chỉ được dùng để thiết lập quyền truy cập workspace."}</p></div></div>
                <div className="mt-7 flex items-center justify-between text-[11px] text-[#9aa5a6]"><span>TMS v1.0 · K15C6</span><a className="inline-flex items-center gap-1 font-semibold text-[#788688] transition-colors hover:text-[#b65342]" href="mailto:support@tms.vn">Cần hỗ trợ <ChevronRight className="h-3 w-3" /></a></div>
              </>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}

function RegisterSuccessState({ fullName, onLogin }: { fullName: string; onLogin: () => void }) {
  return (
    <div className="animate-rise">
      <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#dff2ec] text-[#2d8177] shadow-[0_10px_30px_rgba(61,149,135,0.15)]"><CircleCheck className="h-8 w-8" strokeWidth={2.2} /></div>
      <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-[#3c9b8c]">Đã gửi yêu cầu đăng ký</p>
      <h2 className="font-display text-[clamp(2.25rem,4vw,3.6rem)] font-semibold leading-[0.98] tracking-[-0.065em] text-[#162632]">Chào {fullName || "bạn"}.</h2>
      <p className="mt-5 max-w-[410px] text-sm leading-6 text-[#778389]">Tài khoản của bạn đã được ghi nhận. Quản trị viên sẽ xét duyệt quyền truy cập trước khi bạn bắt đầu làm việc trên TMS.</p>
      <div className="mt-9 flex items-start gap-3 rounded-3xl border border-[#b9ddd5] bg-[#edf8f5] p-5 text-sm leading-6 text-[#36766d]"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" /><span>Hãy kiểm tra email công việc để nhận thông báo khi tài khoản được kích hoạt.</span></div>
      <button type="button" onClick={onLogin} className="primary-button group mt-8 flex w-full items-center justify-center gap-3">Về trang đăng nhập <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 group-hover:translate-x-1" /></button>
    </div>
  );
}

function SuccessState({ account, onReset }: { account: (typeof DEMO_ACCOUNTS)[number]; onReset: () => void }) {
  return (
    <div className="animate-rise">
      <div className="mb-8 flex h-16 w-16 items-center justify-center rounded-[22px] bg-[#dff2ec] text-[#2d8177] shadow-[0_10px_30px_rgba(61,149,135,0.15)]">
        <Check className="h-8 w-8" strokeWidth={2.5} />
      </div>
      <p className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-[#3c9b8c]">Đăng nhập thành công</p>
      <h2 className="font-display text-[clamp(2.25rem,4vw,3.6rem)] font-semibold leading-[0.98] tracking-[-0.065em] text-[#162632]">Chào mừng trở lại.</h2>
      <p className="mt-5 max-w-[400px] text-sm leading-6 text-[#778389]">Bạn đang truy cập workspace với vai trò <strong className="font-semibold text-[#33484f]">{account.role}</strong>.</p>

      <div className="mt-9 flex items-center gap-4 rounded-3xl border border-[#e1e9e5] bg-white/65 p-5">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#122333] font-display text-sm font-semibold text-[#f7f3e9]">{account.initials}</div>
        <div>
          <p className="text-sm font-semibold text-[#243740]">{account.email}</p>
          <p className="mt-1 text-xs text-[#8a9699]">Phiên làm việc an toàn · Đã xác thực</p>
        </div>
        <ShieldCheck className="ml-auto h-5 w-5 text-[#4a9e92]" />
      </div>

      <button type="button" className="primary-button group mt-8 flex w-full items-center justify-center gap-3">
        Vào trang chủ {account.role}
        <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 group-hover:translate-x-1" />
      </button>
      <button type="button" onClick={onReset} className="mt-4 flex w-full items-center justify-center gap-2 text-sm font-semibold text-[#7d898c] transition-colors hover:text-[#bb5745]">
        <UserRound className="h-4 w-4" /> Đăng nhập bằng tài khoản khác
      </button>
    </div>
  );
}
