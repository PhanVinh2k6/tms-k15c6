# TMS — Backend Handoff cho Đăng nhập & Đăng ký

## 1. Phạm vi cần backend triển khai

Frontend hiện có 2 luồng UI:

- **Đăng nhập:** email + mật khẩu, ghi nhớ đăng nhập, khóa tạm sau 5 lần sai liên tiếp, quên mật khẩu.
- **Đăng ký:** họ tên, email công việc, vai trò, mật khẩu, xác nhận mật khẩu, đồng ý điều khoản.

> Hiện tại frontend đang dùng dữ liệu demo trong `client/src/pages/Home.tsx`. Các handler demo cần được thay bằng gọi API thật.

## 2. Các dòng code frontend liên quan

File chính: `client/src/pages/Home.tsx`

| Khu vực | Dòng hiện tại | Ý nghĩa |
|---|---:|---|
| Tài khoản demo | 21–25 | Cần xóa khi backend sẵn sàng |
| State đăng nhập | 37–50 | Các field UI đang thu thập |
| Quy tắc khóa tạm frontend demo | 27, 52–67 | Backend phải là nơi quyết định khóa thật |
| Handler đăng nhập demo | 74–95 | Thay bằng `POST /api/v1/auth/login` |
| Handler quên mật khẩu demo | 97–99 | Thay bằng `POST /api/v1/auth/forgot-password` |
| Handler đăng ký demo | 101–112 | Thay bằng `POST /api/v1/auth/register` |
| Form đăng nhập | 240–252 | Mapping field `email`, `password` |
| Form đăng ký | 253–261 | Mapping field đăng ký |
| Hiển thị lỗi khóa | 226–230 | Dùng `lockedUntil` backend trả về |
| Success login | 289–317 | Dùng user/role backend trả về |
| Success register | 276–287 | Dùng trạng thái `PENDING_APPROVAL` hoặc tương đương |

## 3. API contract đề xuất

Base URL: `/api/v1`

### 3.1 Đăng ký

`POST /api/v1/auth/register`

Request:

```json
{
  "fullName": "Nguyễn Minh Anh",
  "email": "minhanh@tms.vn",
  "password": "123456",
  "role": "STUDENT",
  "acceptedTerms": true
}
```

Quy tắc backend:

- Chuẩn hóa email về lowercase và trim khoảng trắng.
- Không lưu mật khẩu dạng plain text; dùng BCrypt/Argon2.
- Kiểm tra email đã tồn tại.
- Kiểm tra mật khẩu tối thiểu theo policy của hệ thống.
- Chỉ cho phép role mà người đăng ký được tự chọn, ví dụ `STUDENT`, `INSTRUCTOR`, `TA`; không cho tự đăng ký `ADMIN`, `TRAINING_MANAGER`, `ACCOUNTANT` nếu không có phê duyệt.
- Lưu tài khoản với trạng thái `PENDING_APPROVAL` hoặc `ACTIVE` tùy nghiệp vụ.
- Lưu phiên bản điều khoản và thời điểm đồng ý.

Success `201 Created`:

```json
{
  "message": "Đăng ký thành công. Tài khoản đang chờ xét duyệt.",
  "user": {
    "id": "uuid",
    "fullName": "Nguyễn Minh Anh",
    "email": "minhanh@tms.vn",
    "role": "STUDENT",
    "status": "PENDING_APPROVAL"
  }
}
```

### 3.2 Đăng nhập

`POST /api/v1/auth/login`

Request:

```json
{
  "email": "minhanh@tms.vn",
  "password": "123456",
  "rememberMe": true
}
```

Success `200 OK`:

```json
{
  "accessToken": "jwt-access-token",
  "expiresIn": 900,
  "user": {
    "id": "uuid",
    "fullName": "Nguyễn Minh Anh",
    "email": "minhanh@tms.vn",
    "role": "STUDENT",
    "status": "ACTIVE"
  }
}
```

Khuyến nghị:

- Access token thời hạn ngắn, ví dụ 15 phút.
- Refresh token thời hạn dài hơn, lưu trong `HttpOnly + Secure + SameSite` cookie.
- Không trả về thông tin cho biết email có tồn tại hay không.
- Sai email hoặc mật khẩu đều trả cùng một response.

Error `401 Unauthorized`:

```json
{
  "code": "INVALID_CREDENTIALS",
  "message": "Email hoặc mật khẩu không đúng"
}
```

### 3.3 Refresh token

`POST /api/v1/auth/refresh`

- Đọc refresh token từ HttpOnly cookie.
- Trả access token mới.
- Nếu refresh token không hợp lệ/hết hạn: `401 REFRESH_TOKEN_INVALID`.

### 3.4 Đăng xuất

`POST /api/v1/auth/logout`

- Revoke refresh token/session hiện tại.
- Xóa cookie refresh token.
- Trả `204 No Content`.

### 3.5 Quên mật khẩu

`POST /api/v1/auth/forgot-password`

Request:

```json
{
  "email": "minhanh@tms.vn"
}
```

Luôn trả message chung để không lộ email tồn tại:

```json
{
  "message": "Nếu email hợp lệ, hướng dẫn khôi phục sẽ được gửi đến email công việc."
}
```

`POST /api/v1/auth/reset-password`

```json
{
  "token": "reset-token",
  "newPassword": "new-password"
}
```

## 4. Khóa tạm sau 5 lần đăng nhập sai

Đây là logic **bắt buộc backend**, không được chỉ làm ở React state.

Đề xuất bảng/field:

```text
failed_login_attempts integer default 0
locked_until timestamp nullable
last_failed_login_at timestamp nullable
```

Logic:

1. Sai credentials: tăng `failed_login_attempts`.
2. Lần sai thứ 5: set `locked_until = now + 15 minutes`.
3. Trong thời gian khóa: trả `423 Locked`.
4. Đăng nhập đúng: reset `failed_login_attempts = 0`, `locked_until = null`.
5. Hết thời gian khóa: cho phép thử lại và reset counter.
6. Nên rate-limit theo cả account/email và IP để chống brute force.

Response khi bị khóa:

```json
{
  "code": "ACCOUNT_TEMPORARILY_LOCKED",
  "message": "Tài khoản tạm thời bị khóa. Vui lòng thử lại sau.",
  "lockedUntil": "2026-09-26T12:45:00Z",
  "retryAfterSeconds": 742
}
```

## 5. Bảng mã lỗi frontend cần xử lý

| HTTP | Code | Frontend hiển thị |
|---:|---|---|
| 400 | `VALIDATION_ERROR` | Hiển thị lỗi tại field tương ứng |
| 401 | `INVALID_CREDENTIALS` | Email hoặc mật khẩu không đúng |
| 403 | `ACCOUNT_PENDING_APPROVAL` | Tài khoản đang chờ xét duyệt |
| 403 | `ACCOUNT_DISABLED` | Tài khoản đã bị vô hiệu hóa |
| 409 | `EMAIL_ALREADY_EXISTS` | Email đã được sử dụng |
| 423 | `ACCOUNT_TEMPORARILY_LOCKED` | Hiển thị countdown từ `retryAfterSeconds` |
| 429 | `TOO_MANY_REQUESTS` | Vui lòng thử lại sau |
| 500 | `INTERNAL_ERROR` | Có lỗi hệ thống, thử lại sau |

## 6. Việc frontend sẽ làm sau khi backend hoàn tất

Trong `Home.tsx`, thay phần demo ở dòng 74–95 bằng:

```ts
const response = await fetch("/api/v1/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  credentials: "include",
  body: JSON.stringify({ email, password, rememberMe }),
});

const data = await response.json();

if (!response.ok) {
  // map data.code -> error UI
  return;
}

// lưu access token an toàn theo chiến lược của team
// điều hướng theo data.user.role
```

Thay phần demo ở dòng 101–112 bằng:

```ts
const response = await fetch("/api/v1/auth/register", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    fullName,
    email,
    password,
    role: registerRole.toUpperCase(),
    acceptedTerms: agreeTerms,
  }),
});

const data = await response.json();

if (!response.ok) {
  // map lỗi field hoặc data.code -> register-error
  return;
}

setStatus("register-success");
```

## 7. Checklist backend bàn giao

- [ ] Database user, role, status, password hash.
- [ ] Register API.
- [ ] Login API.
- [ ] JWT access token + refresh token.
- [ ] Logout/revoke session.
- [ ] Forgot/reset password.
- [ ] Temporary lock 15 phút sau 5 lần sai.
- [ ] Generic error cho invalid credentials.
- [ ] CORS/credentials/cookie config.
- [ ] Rate limit và audit log.
- [ ] Swagger/OpenAPI để frontend tích hợp chính xác.
- [ ] Seed tài khoản demo cho `STUDENT`, `INSTRUCTOR`, `TRAINING_MANAGER` ở môi trường dev.
